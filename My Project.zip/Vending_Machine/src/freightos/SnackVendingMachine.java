package freightos;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class SnackVendingMachine implements VendingMachine {

    private Inventory<Money> cashInventory = new Inventory<Money>();
    private Inventory<Item> itemInventory = new Inventory<Item>();
    private Item currentItem;
    private long currentBalance;
    private boolean paidByCard;

    public SnackVendingMachine() {
        initialize();
    }

    private void initialize() {
        for (Money c : Money.values()) {
            cashInventory.put(c, 5);
        }
        for (Item i : Item.values()) {
            itemInventory.put(i, 5);
        }

    }

    @Override
    public boolean itemFound() {
        return currentItem == null;
    }

    @Override
    public long selectItemAndGetPrice(int id) {
        Item item = Item.getItem(id);
        if (itemInventory.hasItem(item)) {
            currentItem = item;
            System.out.println("Item available, price is: " + currentItem.getPrice());
            return currentItem.getPrice();
        }
        throw new SoldOutException("Sold Out or Our Wrong Id, Please buy another item");
    }

    @Override
    public void insertMoney(Money coin) {
        if (coin.getValue() == 100000) {
            paidByCard = true;
            return;
        }
        currentBalance += coin.getValue();
        cashInventory.add(coin);
    }

    @Override
    public List<Money> collectItemAndChange() {
        collectItem();
        List<Money> change = collectChange();
        System.out.println("Item disposed!");
        System.out.println("Your change is : " + change);
        return change ;
    }

    private void collectItem() throws NoSufficientChangeException, NotFullPaidException {
        if (currentBalance >= currentItem.getPrice() || paidByCard) {
            if (hasSufficientChange(currentBalance - currentItem.getPrice()) || paidByCard) {
                itemInventory.deduct(currentItem);
                return;
            }
            throw new NoSufficientChangeException("No Sufficient change in Inventory");

        }
        long remainingBalance = currentItem.getPrice() - currentBalance;
        throw new NotFullPaidException("Price not full paid, remaining : ", remainingBalance);
    }

    private List<Money> collectChange() {
        long changeAmount = currentBalance - currentItem.getPrice();
        if (paidByCard) {
            return Collections.EMPTY_LIST;
        }
        List<Money> change = getChange(changeAmount);
        currentBalance = 0;
        currentItem = null;
        return change;
    }

    private List<Money> getChange(long amount) throws NoSufficientChangeException {
        List<Money> changes = Collections.EMPTY_LIST;

        if (amount > 0) {
            changes = new ArrayList<Money>();
            long balance = amount;
            while (balance > 0) {
                if (balance >= Money.TWENTY.getValue()
                        && cashInventory.hasItem(Money.TWENTY)) {
                    changes.add(Money.TWENTY);
                    cashInventory.deduct(Money.TWENTY);
                    balance = balance - Money.TWENTY.getValue();
                    continue;

                } else if (balance >= Money.ONE.getValue()
                        && cashInventory.hasItem(Money.ONE)) {
                    changes.add(Money.ONE);
                    cashInventory.deduct(Money.ONE);
                    balance = balance - Money.ONE.getValue();
                    continue;

                } else if (balance >= Money.FIFTY_C.getValue()
                        && cashInventory.hasItem(Money.FIFTY_C)) {
                    changes.add(Money.FIFTY_C);
                    cashInventory.deduct(Money.FIFTY_C);
                    balance = balance - Money.FIFTY_C.getValue();
                    continue;

                } else if (balance >= Money.TWENTY_C.getValue()
                        && cashInventory.hasItem(Money.TWENTY_C)) {
                    changes.add(Money.TWENTY_C);
                    cashInventory.deduct(Money.TWENTY_C);
                    balance = balance - Money.TWENTY_C.getValue();
                    continue;

                } else if (balance >= Money.TEN_C.getValue()
                        && cashInventory.hasItem(Money.TEN_C)) {
                    changes.add(Money.TEN_C);
                    cashInventory.deduct(Money.TEN_C);
                    balance = balance - Money.TEN_C.getValue();
                    continue;

                } else {
                    throw new NoSufficientChangeException("No Sufficient Change,Please try another product");
                }
            }
        }

        return changes;
    }

    private boolean hasSufficientChange(long amount) {
        boolean hasChange = true;
        try {
            getChange(amount);
        } catch (NoSufficientChangeException nsce) {
            return hasChange = false;
        }

        return hasChange;
    }

    @Override
    public void displayProducts() {
        int lineCount = 0;
        System.out.println("*      Wellcome - :) -       *");
        for (Item item : Item.values()) {
            if (lineCount % 5 == 0) {
                System.out.println("\n");
            }
            System.out.print("Item: " + item.getName() + " | ");
            lineCount++;
        }
        System.out.println("\n*    Please select a Product    *");
    }

    @Override
    public boolean fullPaid() {
        if (currentItem == null) {
            return false;
        }
        return currentBalance < currentItem.getPrice();
    }

}

