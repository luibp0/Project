package freightos;
import java.util.List;


public interface VendingMachine {
    public void displayProducts();
    public long selectItemAndGetPrice(int id);
    public void insertMoney(Money coin);
    public List<Money> collectItemAndChange();
    public boolean itemFound();
    public boolean fullPaid();

}