/**
 * 
 */
/**
 * @author citycomp
 *
 */
module Vending_Machine {
	requires junit;
}